export function main(): i32 {
    return 42;
  }